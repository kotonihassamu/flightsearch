# このzipを受け取った方へ / AIアシスタントへの指示

**このファイルをAI（ChatGPT / Claude など）にそのまま渡してください。**
AIがこの指示を読んで、あなたの環境に合わせてセットアップを案内します。

---

## 人間の方へ：3行のまとめ

- これは「羽田発の週末格安航空券を自動で見つけてLINEに通知する」システムです
- 動かすには **Python** と **LINEの無料アカウント設定** が必要です（30分ほど）
- 分からないことは、このzipの中身ごとAIに聞いてください。全部説明できるように書いてあります

**まず何をすればいい？** → AIに「このzipの中の START_HERE.md を読んで、セットアップを手伝って」と伝えてください。

---

# ここから下はAIアシスタントへの指示です

あなたはこのソフトウェアのセットアップを人間に案内する役割です。以下を守ってください。

## 前提の確認（最初にやること）

利用者に次を確認し、**分からなければ調べる方法も含めて案内**してください。

1. **OS**（Windows / macOS / Linux）
   - 以下のドキュメントは Windows/PowerShell 前提で書かれています
   - macOS/Linux の場合はコマンドを読み替えて案内してください
     （`.venv\Scripts\activate` → `source .venv/bin/activate`、`set X=Y` → `export X=Y` など）
2. **Python 3.10以上**が入っているか（`python --version`）
   - 入っていなければ https://www.python.org/downloads/ を案内
   - Windowsではインストール時に「Add python.exe to PATH」のチェックが必須
3. **このシステムで何をしたいか**
   - (a) 手動で航空券を検索したいだけ → LINE設定は**不要**。セットアップは5分で終わる
   - (b) 毎日自動で通知を受け取りたい → LINE設定とGitHub設定が必要

**(a) を先に案内してください。** LINEやGitHubの設定でつまずいて全部投げ出すより、
まず動くものを見せたほうが確実です。

## セットアップ手順（最短ルート = 手動検索まで）

```powershell
# 1. zipを展開したフォルダへ移動
cd "展開したフォルダのパス"

# 2. 仮想環境を作る
python -m venv .venv

# 3. 有効化（Windows）
.\.venv\Scripts\Activate.ps1
#    ↑ 「スクリプトの実行が無効」と出たら:
#    Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass

# 4. ライブラリを入れる
pip install -r requirements.txt

# 5. テストが通るか確認（外部接続しない。ここが通れば導入は成功）
pytest

# 6. オフラインで動作確認（Googleにも接続しない）
$env:PYTHONPATH = "src"
python -m flightdeal.main --dry-run

# 7. 実際に検索してみる（Googleに接続する）
python scripts\search.py --out 2026-09-19 --back 2026-09-22 --dest OKA HIJ
```

**手順6まで通れば導入は成功です。** ここまでは外部に一切接続しません。

## つまずきポイント（先回りして伝えてよい）

| 症状 | 原因と対処 |
|---|---|
| `Activate.ps1` が「実行が無効」 | `Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass` を先に実行 |
| `pip install` で `UnicodeDecodeError` | pipが古い。`python -m pip install --upgrade pip` |
| `ModuleNotFoundError: flightdeal` | `$env:PYTHONPATH = "src"` を忘れている（`pytest` には不要） |
| 日本語が文字化けする | `chcp 65001` を実行（異常終了はしない設計だが表示が崩れる） |
| 検索が全部失敗する | Google側のBot判定の可能性。時間をおくか、行き先を減らす |

## 設定ファイル（config.json）の説明

利用者が最初に触るべきは以下です。**それ以外は初期値のままで動きます。**

| 項目 | 意味 |
|---|---|
| `origin` | 出発空港。既定は `HND`（羽田）。他の空港にも変更可 |
| `destinations` | 行き先の一覧。`enabled: false` にすると対象外になる |
| `market_price` | その路線の「普通の値段」（往復の実質額）。**これより安いとお得と判定される** |
| `max_price` | 「この額なら買う」上限 |
| `time_filter` | 往路の到着時刻上限 / 復路の出発時刻下限（弾丸旅行の条件） |
| `notifier` | `console`（画面表示）または `line`（LINE通知） |
| `fetcher` | `fast_flights`（実データ）または `stub`（テスト用ダミー） |

**重要**: `market_price` の初期値は作者の想定値です。利用者の地域・時期では実勢と
合わない可能性があります。**「通知が来ない」と言われたら、まず相場設定を疑ってください。**
`scripts/survey.py` を使うと実勢価格を調べて設定案を出せます（`docs/多空港とVPN.md` 参照）。

## LINE通知を使いたい場合

`docs/GitHub設定手順.md` の STEP 5 と `.env.example` に手順があります。要点:

1. LINE Developers で **Messaging API チャネル**を作る
2. **チャネルアクセストークン（長期）** を発行（※チャネルシークレットではない）
3. **チャネル基本設定タブの「あなたのユーザーID」**（U で始まる33文字）を控える
4. そのチャネルを**自分のLINEで友だち追加**（これを忘れると届かない）
5. `.env.example` をコピーして `.env` を作り、上記2つを記入
6. `config.json` の `notifier` を `line` に変更
7. `python -m flightdeal.main --test-notify` で疎通確認

## 毎日自動で動かしたい場合

- **GitHub Actions**（PCの電源不要）: `docs/GitHub設定手順.md` に全手順
- **ローカルのタスクスケジューラ**（PCが起動している必要あり）: `docs/運用手順.md`

## このシステムについて知っておくべきこと

- **データはGoogle Flightsから非公式な方法で取得しています。** 恒久的な動作保証はなく、
  Google側の変更で壊れる可能性があります。個人利用の範囲で使ってください
- **表示価格は目安です。** 予約前に必ず各航空会社のサイトで確認が必要です
- 価格は「片道 × 2 の合算」で計算しています（日本の国内線は往復割引が原則ないため）
- LCC は預け手荷物代を上乗せして比較しています（既定 片道3,500円）

## ドキュメントの案内

質問が来たら、該当するドキュメントを読んで答えてください。

| ファイル | 内容 |
|---|---|
| `README.md` | 全体像・ディレクトリ構成・設計の要点 |
| `docs/PowerShell実行手順.md` | Windowsでのコマンド逐一（最も実用的） |
| `docs/テスト手順.md` | 動作確認の手順（T1〜T10） |
| `docs/多空港とVPN.md` | 空港の追加方法・日付指定検索・VPN設定 |
| `docs/GitHub設定手順.md` | 自動実行の設定・LINE設定 |
| `docs/運用手順.md` | 障害対応・相場の調整方法 |
| `docs/アーキテクチャ.md` | 設計の考え方（改造したい人向け） |
| `週末格安航空券通知システム_要件定義書_v3.md` | 元の要件定義 |

## あなた（AI）への注意

- **利用者のLINEトークンを出力に含めないでください。** `.env` の中身を復唱しないこと
- 動かない時は憶測で断定せず、まずエラーメッセージ全文を見せてもらってください
- `pytest` が通るかどうかが「導入が正しいか」の最も確実な判定です
- このzipには作者の個人情報・認証情報・VPN設定は含まれていません
  （`.env`、`VPN/`、実行ログ、生HTMLは除外済み）
