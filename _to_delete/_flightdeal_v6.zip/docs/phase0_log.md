# Phase 0 技術検証ログ

> 完了条件: 3日連続で、価格・時刻・航空会社名が取得できること（要件2）

`python scripts\\phase0_check.py --dest HIJ --save` の結果を毎日追記する。

## ライブラリ調査

| 項目 | 内容 | 確認日 |
|---|---|---|
| fast-flights バージョン | 3.0.2 | 2026-07-27 |
| API | 2系から全面変更。FlightQuery + create_filter + parse | 2026-07-27 |
| primp（内部HTTP） | 環境依存でDNS "Query Refused"。requests方式で回避 | 2026-07-27 |
| 採用判断 | fast-flights（取得=requests / 解析=parser）で確定 | 2026-07-27 |

---

## 実行記録

### Day 1（2026-07-27）✅

- 区間 / 対象日: HND -> HIJ / 2026-08-01
- 方式: FastFlightsFetcher（requests + fast-flights parser）
- 結果: **成功**
- 取得件数: 12件
- 航空会社名: 取得可（ANA / JAL）
- 出発・到着時刻: 取得可
- 価格（JPY）: 取得可（ANA 20,590 / JAL 22,790）
- 直行便の絞り込み: 可（max_stops=0）
- 便名: 取得不可（parserが非対応。None扱い・仕様上は任意）
- 備考: primp直呼びはDNS拒否で失敗。requests経由で解決。

### Day 2（____-__-__）

- 実行日時:
- 結果:
- 取得件数:
- 備考:

### Day 3（____-__-__）

- 実行日時:
- 結果:
- 取得件数:
- 備考:

---

## 判断（0-8）

- 採用方式: fast-flights（取得=requests / 解析=fast_flights.parser、primp回避）
- 判断日: 2026-07-27（1日目成功。3日連続確認で正式完了）
- 理由: primpがこの環境でDNS拒否されるため。requestsは正常動作。
- 保存したフィクスチャ: （--save で tests/fixtures/ に保存）
