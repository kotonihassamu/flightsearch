"""設定読み込み・検証のテスト。骨組み段階から通る（xfailなし）。"""

from __future__ import annotations

from datetime import time

import pytest

from flightdeal.config import _from_dict


def test_load_default_config(cfg):
    assert cfg.origin == "HND"
    assert len(cfg.destinations) == 5
    assert [d.iata for d in cfg.enabled_destinations] == ["HIJ", "MYJ"]  # Phase 1
    assert cfg.weekends_ahead == 1
    assert cfg.time_filter.outbound_arrive_by == time(11, 0)
    assert cfg.time_filter.return_depart_after == time(17, 0)
    assert cfg.baggage_surcharge_oneway == 3500
    assert cfg.notify_top_n_per_route == 3


def test_phase3_switch_without_code_change(cfg):
    """enabled と weekends_ahead だけで Phase 3 相当へ移行できること（要件4.5）。"""
    data = {
        "origin": cfg.origin,
        "destinations": [
            {
                "iata": d.iata,
                "name": d.name,
                "market_price": d.market_price,
                "max_price": d.max_price,
                "enabled": True,
            }
            for d in cfg.destinations
        ],
        "weekends_ahead": 2,
        "time_filter": {"outbound_arrive_by": "11:00", "return_depart_after": "17:00"},
        "baggage_surcharge_oneway": 3500,
        "lcc_airlines": cfg.lcc_airlines,
        "fsc_airlines": cfg.fsc_airlines,
        "rank_thresholds": {"S": 0.70, "A": 0.85},
        "notify_top_n_per_route": 3,
        "search": {"max_searches_per_run": 20},
    }
    loaded = _from_dict(data)
    assert len(loaded.enabled_destinations) == 5
    # 5路線 × 2週末 × 2方向 = 20 = 上限ちょうど（要件4.3）
    assert len(loaded.enabled_destinations) * loaded.weekends_ahead * 2 == 20


def test_search_limit_exceeded_raises(cfg):
    data = {
        "origin": "HND",
        "destinations": [
            {"iata": "HIJ", "name": "広島", "market_price": 35000, "max_price": 30000, "enabled": True}
        ],
        "weekends_ahead": 2,
        "time_filter": {"outbound_arrive_by": "11:00", "return_depart_after": "17:00"},
        "baggage_surcharge_oneway": 3500,
        "lcc_airlines": ["Peach"],
        "fsc_airlines": ["ANA"],
        "rank_thresholds": {"S": 0.70, "A": 0.85},
        "notify_top_n_per_route": 3,
        "search": {"max_searches_per_run": 2},
    }
    with pytest.raises(ValueError, match="検索回数"):
        _from_dict(data)


def test_invalid_thresholds_raise():
    data = {
        "origin": "HND",
        "destinations": [
            {"iata": "HIJ", "name": "広島", "market_price": 35000, "max_price": 30000, "enabled": True}
        ],
        "weekends_ahead": 1,
        "time_filter": {"outbound_arrive_by": "11:00", "return_depart_after": "17:00"},
        "baggage_surcharge_oneway": 3500,
        "lcc_airlines": [],
        "fsc_airlines": [],
        "rank_thresholds": {"S": 0.90, "A": 0.85},  # S > A は不正
        "notify_top_n_per_route": 3,
    }
    with pytest.raises(ValueError, match="rank_thresholds"):
        _from_dict(data)
