# フィクスチャ（要件6.2）

外部サイトへ接続するテストは CI の合否条件に含めない。
代わりに、Phase 0 で実際に取得した結果をここに保存し、パース部の回帰テストに使う。

## ファイル名規則

```
<ORIGIN>-<DEST>-<YYYY-MM-DD>.json
例: HND-HIJ-2026-08-01.json
```

## 正規化済みフィクスチャ（FixtureFetcher が読む形式）

```json
[
  {"airline": "ANA", "depart_time": "07:25", "arrive_time": "08:50", "price": 11400, "flight_number": "NH673"}
]
```

## 生レスポンス

パーサ（`FastFlightsFetcher._to_flight`）の回帰テスト用に、ライブラリから返る
生データや Playwright 採用時の HTML を `raw/` 配下へ保存する。

```
raw/HND-HIJ-2026-08-01.fast-flights.json
raw/HND-HIJ-2026-08-01.html
```

生データを保存する際は、個人情報や認証トークンが含まれていないことを確認すること。

> `HND-HIJ-2026-08-01.json` は現在ダミーです。Phase 0 で実データに差し替えてください。
