"""安さランク判定と上位N件の抽出（要件3.5）。

判定は上から順に、最初に該当したランクを採用する。
  S: 実質価格 <= 相場 × 0.70
  A: 実質価格 <= 相場 × 0.85
  B: 実質価格 <  相場  かつ  実質価格 <= max_price
  それ以外: ランク外（通知しない）
"""

from __future__ import annotations

from .config import Config
from .models import Combination, Rank, RouteConfig


def judge_rank(total_price: int, route: RouteConfig, cfg: Config) -> Rank:
    """実質価格から安さランクを判定する。

    TODO(Phase 1): 実装する。

    境界値テスト必須（要件6.1）:
      - total == market_price * 0.70  -> S（以下なので該当）
      - total == market_price * 0.85  -> A
      - total == market_price         -> ランク外（B は「未満」）
      - total == max_price かつ相場未満 -> B
      - total == max_price + 1 かつ相場未満 -> ランク外
    注意: 相場×係数は float になるため、比較前の丸め方針を決めること
          （推奨: int(market_price * threshold) で切り捨ててから比較）
    """
    raise NotImplementedError("judge_rank は Phase 1 で実装する")


def top_n_per_route(combinations: list[Combination], n: int) -> list[Combination]:
    """同一路線・同一週末でランク入りが複数ある場合、安い順に上位N件へ絞る。

    TODO(Phase 1): 実装する。
      - キー: (route.iata, weekend.index)
      - ランク外（Rank.NONE）は除外
      - 並び順: 実質価格の昇順、同額なら往路出発時刻の昇順
    """
    raise NotImplementedError("top_n_per_route は Phase 1 で実装する")
