"""週末日付の算出（要件3.1「対象日程」）。

純粋関数として実装し、pytest で境界値を検証する（要件6.1）。

仕様:
  - 実行日を基準に、次に到来する土曜日を「第1週末」とする
  - 実行日が土曜の場合は当日を含めず、翌週土曜を第1週末とする
  - 日曜は第1週末の土曜の翌日
  - 第2週末は第1週末の7日後
"""

from __future__ import annotations

from datetime import date

from .models import WeekendDates

SATURDAY = 5  # date.weekday(): Mon=0 ... Sat=5, Sun=6


def next_saturday(today: date) -> date:
    """today を基準にした「第1週末」の土曜日を返す。

    TODO(Phase 1): 実装する。
      - today.weekday() == SATURDAY のときは today + 7日
      - それ以外は次に到来する土曜日
      - 日曜(6)の場合、次の土曜は6日後になる点に注意

    検証すべき境界（要件6.1）:
      金曜 -> 翌日, 土曜 -> 8日後ではなく7日後, 日曜 -> 6日後
    """
    raise NotImplementedError("next_saturday は Phase 1 で実装する")


def target_weekends(today: date, weekends_ahead: int) -> list[WeekendDates]:
    """対象となる週末のリストを返す。

    TODO(Phase 1): 実装する。
      - next_saturday() を起点に weekends_ahead 個ぶん、7日刻みで生成
      - 各要素の index は 1 始まり
    """
    raise NotImplementedError("target_weekends は Phase 1 で実装する")
