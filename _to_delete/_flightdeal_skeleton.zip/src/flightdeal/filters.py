"""時間帯フィルターと組み合わせ生成（要件3.3 / 3.2.1）。

すべて純粋関数。外部I/Oを持ち込まないこと。
"""

from __future__ import annotations

from datetime import time

from .models import Flight


def filter_outbound(flights: list[Flight], arrive_by: time) -> list[Flight]:
    """往路（土曜）: 現地到着時刻が arrive_by 以前の便のみを残す。

    TODO(Phase 1): 実装する。境界値（到着 == arrive_by）は「含む」。
    """
    raise NotImplementedError("filter_outbound は Phase 1 で実装する")


def filter_return(flights: list[Flight], depart_after: time) -> list[Flight]:
    """復路（日曜）: 現地出発時刻が depart_after 以降の便のみを残す。

    TODO(Phase 1): 実装する。境界値（出発 == depart_after）は「含む」。
    """
    raise NotImplementedError("filter_return は Phase 1 で実装する")


def combine(outbounds: list[Flight], inbounds: list[Flight]) -> list[tuple[Flight, Flight]]:
    """往路×復路の総当たり組み合わせを生成する（要件3.2.1）。

    TODO(Phase 1): 実装する。
      - 単純な直積で良い（国内線・同一週末のため日付整合チェックは不要）
      - どちらかが空リストなら空リストを返す
      - 件数が爆発しないよう、必要なら上限を設けるか検討する
    """
    raise NotImplementedError("combine は Phase 1 で実装する")


def is_complete(flight_like: dict) -> bool:
    """取得結果に必須項目が揃っているか判定する（要件3.2.2「除外」）。

    TODO(Phase 1): 実装する。
      必須: airline, depart_time, arrive_time, price
      欠損している場合は False を返し、呼び出し側が除外件数をログに記録する。
    """
    raise NotImplementedError("is_complete は Phase 1 で実装する")
