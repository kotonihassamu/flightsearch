"""実行パイプライン（要件3.2.1 / 4.3）。

処理の流れ:
    週末算出
      └ 路線ごと（try-except で隔離）
          ├ 往路検索（HND -> 目的地, 土曜）  ※リトライ最大2回・検索間ランダム待機
          ├ 復路検索（目的地 -> HND, 日曜）
          ├ 時間帯フィルター
          ├ 総当たり組み合わせ
          ├ 手荷物補正 + 実質価格
          └ ランク判定 → 上位N件
    集約 → 通知判断
"""

from __future__ import annotations

import logging
import random
import time as time_mod
from datetime import date

from .config import Config
from .fetchers import FetchError, FlightFetcher
from .models import Direction, Flight, RouteConfig, RouteResult, RunResult, WeekendDates

log = logging.getLogger(__name__)


def fetch_with_retry(
    fetcher: FlightFetcher,
    origin: str,
    destination: str,
    flight_date: date,
    cfg: Config,
) -> list[Flight]:
    """リトライ付きで1検索を実行する（要件4.3）。

    TODO(Phase 1): 実装する。
      - 最大 cfg.search.retry_max 回まで再試行、間に cfg.search.retry_wait_seconds 待機
      - 最終的に失敗したら FetchError を送出
      - 各試行の結果を構造化ログに出力（区間・日付・件数・所要時間）
    """
    raise NotImplementedError("fetch_with_retry は Phase 1 で実装する")


def sleep_between_searches(cfg: Config) -> None:
    """検索間のランダム待機（要件4.3 負荷抑制）。実装済み。"""
    lo, hi = cfg.search.sleep_between_searches
    wait = random.uniform(lo, hi)
    log.info("sleep_between_searches", extra={"seconds": round(wait, 1)})
    time_mod.sleep(wait)


def process_route(
    fetcher: FlightFetcher,
    route: RouteConfig,
    weekend: WeekendDates,
    cfg: Config,
) -> RouteResult:
    """1路線・1週末を処理する。例外はここで捕まえ RouteResult.error に格納する。

    TODO(Phase 1): 実装する。
      1. 往路 fetch_with_retry(cfg.origin, route.iata, weekend.saturday)
      2. sleep_between_searches()
      3. 復路 fetch_with_retry(route.iata, cfg.origin, weekend.sunday)
      4. filters.filter_outbound / filter_return
      5. filters.combine
      6. pricing.effective_price
      7. ranking.judge_rank -> Combination 生成
      8. ranking.top_n_per_route(..., cfg.notify_top_n_per_route)
      FetchError は捕捉して RouteResult(error=...) を返し、全体を止めないこと。
    """
    raise NotImplementedError("process_route は Phase 1 で実装する")


def run(fetcher: FlightFetcher, cfg: Config, today: date | None = None) -> RunResult:
    """1実行分のパイプラインを回す。

    TODO(Phase 1): 実装する。
      - weekend.target_weekends(today or date.today(), cfg.weekends_ahead)
      - cfg.enabled_destinations × 週末 でループし process_route を呼ぶ
      - 検索回数が cfg.search.max_searches_per_run を超えないよう打ち切る
      - 所要時間を計測して RunResult.elapsed_seconds に格納
    """
    raise NotImplementedError("run は Phase 1 で実装する")


# 参考: Direction は将来ログのラベル付けに使う
_ = Direction
