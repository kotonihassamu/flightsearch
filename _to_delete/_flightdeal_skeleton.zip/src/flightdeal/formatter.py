"""通知本文の組み立て（要件3.6）。

原則: リンクが機能しなくても、本文情報だけで航空会社サイトから予約行動に移れること。

フォーマット例（要件3.6）:
    【S】羽田⇔広島 8/1(土)〜8/2(日)
    実質 ¥22,800（相場 ¥35,000 / ▲35%）
    往路: ANA 07:25発 → 08:50着（¥11,400）
    復路: ANA 19:05発 → 20:30着（¥11,400）
    補正: なし（FSC）
    検索: https://www.google.com/travel/flights?hl=ja&curr=JPY&q=HND to HIJ 2026-08-01
"""

from __future__ import annotations

from datetime import date

from .models import Combination, RunResult

MAX_TEXT_LENGTH = 5000
WEEKDAY_JA = ["月", "火", "水", "木", "金", "土", "日"]


def search_url(origin: str, destination: str, flight_date: date) -> str:
    """Google Flights の検索URLを生成する（要件P5: 予約直リンクは使わない）。

    TODO(Phase 1): 実装する。
      https://www.google.com/travel/flights?hl=ja&curr=JPY&q=<query>
      query は "HND to HIJ 2026-08-01" を URLエンコードしたもの。
      リンクはあくまで補助であり、切れても本文だけで行動できること。
    """
    raise NotImplementedError("search_url は Phase 1 で実装する")


def format_date_range(saturday: date, sunday: date) -> str:
    """'8/1(土)〜8/2(日)' 形式の文字列を返す。

    TODO(Phase 1): 実装する。WEEKDAY_JA を利用。
    """
    raise NotImplementedError("format_date_range は Phase 1 で実装する")


def format_combination(combo: Combination) -> str:
    """1件分の通知ブロックを組み立てる。

    TODO(Phase 1): 実装する。要件3.6 の必須項目をすべて含めること。
      - 路線・日付・ランク
      - 実質価格 / 相場 / 割引率（combo.discount_rate）
      - 往復それぞれの航空会社・出発/到着時刻・片道価格
      - 補正の内訳。combo.provisional_surcharge が True なら「補正額は仮」と明記
      - 検索URL
    """
    raise NotImplementedError("format_combination は Phase 1 で実装する")


def format_run(result: RunResult) -> str:
    """全結果を1通に集約した本文を返す（要件3.6 集約）。

    TODO(Phase 1): 実装する。
      - ランク入り0件なら空文字を返す（呼び出し側は通知しない）
      - 路線→週末→価格の順に並べる
      - 末尾に「表示価格は目安です。予約前に必ず各社サイトで確認してください」を付す
    """
    raise NotImplementedError("format_run は Phase 1 で実装する")


def format_failure(result: RunResult) -> str:
    """全路線失敗時の障害通知本文（要件4.3 サイレント障害防止）。

    TODO(Phase 2): 実装する。
      - 失敗した路線名とエラー要旨（スタックトレースは含めない）
      - 「連続3日失敗ならローカル実行へ切替」の運用基準（要件4.1）を想起させる文言
    """
    raise NotImplementedError("format_failure は Phase 2 で実装する")


def split_message(text: str, limit: int = MAX_TEXT_LENGTH) -> list[str]:
    """LINEの文字数上限で分割する（要件3.6: 5,000文字超の場合のみ分割）。

    TODO(Phase 2): 実装する。
      - limit 以下ならそのまま1要素のリストを返す
      - 分割は「1件分のブロック」の境界（空行）で行い、途中で切らないこと
    """
    raise NotImplementedError("split_message は Phase 2 で実装する")
