"""LINE Messaging API（Push Message）通知（要件3.6 / 4.4）。

LINE Notify はサービス終了済みのため使用しない。

必要な環境変数（GitHub Secrets / ローカルは .env）:
  LINE_CHANNEL_ACCESS_TOKEN  チャネルアクセストークン（長期）
  LINE_TO_USER_ID            送信先ユーザーID（自分のUID）

トークン・UIDはコードにもログにも出力しないこと（要件4.4）。
"""

from __future__ import annotations

import os

from .base import Notifier, NotifyError

PUSH_ENDPOINT = "https://api.line.me/v2/bot/message/push"
MAX_TEXT_LENGTH = 5000  # LINE のテキストメッセージ上限


class LineNotifier(Notifier):
    name = "line"

    def __init__(self, token: str | None = None, to_user_id: str | None = None) -> None:
        self.token = token or os.environ.get("LINE_CHANNEL_ACCESS_TOKEN", "")
        self.to_user_id = to_user_id or os.environ.get("LINE_TO_USER_ID", "")

    @property
    def configured(self) -> bool:
        return bool(self.token and self.to_user_id)

    def send(self, text: str) -> None:
        """Push Message を送信する。

        TODO(Phase 2): 実装する。
          1. configured が False なら NotifyError（設定漏れの早期検知）
          2. text を MAX_TEXT_LENGTH で分割（formatter.split_message を利用）
          3. requests.post(PUSH_ENDPOINT, headers={
                 "Authorization": f"Bearer {self.token}",
                 "Content-Type": "application/json"},
                 json={"to": self.to_user_id,
                       "messages": [{"type": "text", "text": chunk}]},
                 timeout=20)
          4. status_code != 200 の場合、レスポンス本文を含めて NotifyError
             ※ ただしトークンは絶対にログへ出さない
          5. 送信数は無料枠に配慮し1実行あたり最大2通に抑える（要件R6）
        """
        raise NotImplementedError("LineNotifier.send は Phase 2 で実装する")
