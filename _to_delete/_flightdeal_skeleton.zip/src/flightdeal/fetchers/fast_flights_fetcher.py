"""優先度1: fast-flights を用いた取得実装（要件3.2.2）。

ブラウザ不要・軽量。ただし非公式ライブラリでありメンテ状況に依存するため、
Phase 0 で以下を必ず確認してから採用可否を判断する。

  [ ] ライブラリの最新リリース日・Issue の状況
  [ ] HND -> HIJ の片道価格が取得できるか
  [ ] 取得結果に「航空会社名 / 出発時刻 / 到着時刻 / 価格」が揃っているか
  [ ] 3日連続で成功するか（Phase 0 完了条件）
  [ ] 直行便のみへの絞り込みが可能か（不可なら取得後にローカルで除外）

fast-flights の API は版によって変わるため、_to_flight() のマッピングは
Phase 0 で実際のレスポンスを見てから確定させること。
"""

from __future__ import annotations

from datetime import date

from ..models import Flight
from .base import FetchError, FlightFetcher


class FastFlightsFetcher(FlightFetcher):
    """fast-flights ラッパー。"""

    name = "fast_flights"

    def __init__(self, currency: str = "JPY", locale: str = "ja", max_stops: int = 0) -> None:
        self.currency = currency
        self.locale = locale
        self.max_stops = max_stops  # 0 = 直行便のみ（要件3.1）

    def fetch(self, origin: str, destination: str, flight_date: date) -> list[Flight]:
        """片道検索を1回実行する。

        TODO(Phase 0 -> Phase 1): 実装する。
          1. fast_flights を import（未インストール時は FetchError に変換）
          2. FlightData(date=..., from_airport=origin, to_airport=destination) を組み立て
          3. get_flights(flight_data=[...], trip="one-way", seat="economy",
                         passengers=Passengers(adults=1), fetch_mode="fallback")
          4. 結果を _to_flight() で Flight に変換
          5. 例外はすべて FetchError にラップして送出（要件4.3 路線単位の隔離）

        取得できない項目がある便は None を返して呼び出し側で除外し、
        除外件数をログに記録すること（要件3.2.2）。
        """
        raise NotImplementedError("FastFlightsFetcher.fetch は Phase 0 検証後に実装する")

    def _to_flight(self, raw: object, origin: str, destination: str, flight_date: date) -> Flight | None:
        """ライブラリの1件を Flight に変換する。欠損があれば None。

        TODO(Phase 0 -> Phase 1): 実装する。
          - 価格は pricing.parse_price() で整数化
          - 時刻は "7:25 AM on Sat, Aug 1" 形式などから time を抽出（版により異なる）
          - 直行便判定（stops == 0）をここで行う
        """
        raise NotImplementedError("_to_flight は Phase 0 検証後に実装する")


def _raise_if_missing() -> None:
    """fast-flights 未インストール時に分かりやすいエラーを出すヘルパ。"""
    try:
        import fast_flights  # noqa: F401
    except ImportError as e:  # pragma: no cover
        raise FetchError(
            "fast-flights がインストールされていません。"
            "`pip install -r requirements.txt` を実行してください。"
        ) from e
