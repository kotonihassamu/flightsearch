"""LCC手荷物料金の補正と実質価格の算出（要件3.4）。

補正は片道単位。
  実質価格（往復） = 往路価格 + 往路補正 + 復路価格 + 復路補正
"""

from __future__ import annotations

from .config import Config
from .models import AirlineClass, Flight


def parse_price(raw: str | int) -> int:
    """'¥11,400' / '11400' などを整数に正規化する（要件3.2.2）。

    TODO(Phase 1): 実装する。
      - カンマ・通貨記号・空白を除去して int 化
      - 数値が取り出せない場合は ValueError を送出（呼び出し側で除外扱い）
    """
    raise NotImplementedError("parse_price は Phase 1 で実装する")


def classify_airline(airline: str, cfg: Config) -> AirlineClass:
    """航空会社名から補正区分を判定する（要件3.4）。

    TODO(Phase 1): 実装する。
      - fsc_airlines / lcc_airlines に対する部分一致（大文字小文字無視）で判定
      - "Solaseed Air" と設定値 "Solaseed" のような表記ゆれを吸収すること
      - どちらにも該当しなければ AirlineClass.UNKNOWN
    """
    raise NotImplementedError("classify_airline は Phase 1 で実装する")


def surcharge_for(airline: str, cfg: Config) -> tuple[int, bool]:
    """片道あたりの補正額と「暫定フラグ」を返す（要件3.4）。

    Returns:
        (補正額, provisional)
        provisional=True のとき、通知本文に「補正額は仮」の注記を入れる。

    TODO(Phase 1): 実装する。
      - FSC     -> (0, False)
      - LCC     -> (cfg.baggage_surcharge_oneway, False)
      - UNKNOWN -> (cfg.baggage_surcharge_oneway, True)
    """
    raise NotImplementedError("surcharge_for は Phase 1 で実装する")


def effective_price(outbound: Flight, inbound: Flight, cfg: Config) -> tuple[int, int, int, bool]:
    """実質価格（往復）を算出する。

    Returns:
        (実質価格, 往路補正, 復路補正, provisional)

    TODO(Phase 1): 実装する。surcharge_for を往復それぞれに適用して合算。
    """
    raise NotImplementedError("effective_price は Phase 1 で実装する")
