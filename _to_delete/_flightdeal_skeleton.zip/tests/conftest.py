from __future__ import annotations

import sys
from datetime import date, time
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from flightdeal.config import load_config  # noqa: E402
from flightdeal.models import Flight, RouteConfig, WeekendDates  # noqa: E402


@pytest.fixture
def cfg():
    return load_config(ROOT / "config.json")


@pytest.fixture
def route_hij():
    return RouteConfig(iata="HIJ", name="広島", market_price=35000, max_price=30000, enabled=True)


@pytest.fixture
def weekend_aug1():
    return WeekendDates(saturday=date(2026, 8, 1), sunday=date(2026, 8, 2), index=1)


def make_flight(
    airline="ANA",
    dep="07:25",
    arr="08:50",
    price=11400,
    origin="HND",
    destination="HIJ",
    flight_date=date(2026, 8, 1),
):
    dh, dm = dep.split(":")
    ah, am = arr.split(":")
    return Flight(
        origin=origin,
        destination=destination,
        flight_date=flight_date,
        airline=airline,
        depart_time=time(int(dh), int(dm)),
        arrive_time=time(int(ah), int(am)),
        price=price,
    )
