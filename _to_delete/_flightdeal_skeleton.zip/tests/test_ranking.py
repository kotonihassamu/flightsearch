"""ランク判定の境界値テスト（要件6.1）。

相場 35,000 / max_price 30,000 / S=0.70 / A=0.85 を前提とする。
  S 境界: 24,500
  A 境界: 29,750
  B 条件: 35,000 未満 かつ 30,000 以下
"""

from __future__ import annotations

import pytest

from flightdeal import ranking
from flightdeal.models import Rank

pytestmark = pytest.mark.xfail(reason="ranking.py は Phase 1 で実装", strict=False)


@pytest.mark.parametrize(
    "total,expected",
    [
        (24_499, Rank.S),
        (24_500, Rank.S),    # 相場×0.70 ちょうど -> 以下なので S
        (24_501, Rank.A),
        (29_750, Rank.A),    # 相場×0.85 ちょうど
        (29_751, Rank.B),    # A外だが max_price 以下・相場未満
        (30_000, Rank.B),    # max_price ちょうど
        (30_001, Rank.NONE), # max_price 超過
        (34_999, Rank.NONE),
        (35_000, Rank.NONE), # 相場と同額 -> B は「未満」なので該当しない
        (40_000, Rank.NONE),
    ],
)
def test_judge_rank_boundaries(total, expected, route_hij, cfg):
    assert ranking.judge_rank(total, route_hij, cfg) is expected


def test_top_n_per_route_sorted_and_limited():
    """同一路線・同一週末は安い順に上位3件まで（要件3.5）。"""
    pytest.skip("Combination のファクトリを Phase 1 で用意してから有効化する")
