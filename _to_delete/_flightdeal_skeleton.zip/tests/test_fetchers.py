"""取得層のテスト。

外部サイトへ接続するテストは書かない（要件6.2: CIの合否条件に含めない）。
実取得の検証は Phase 0 で手元PCの scripts/phase0_check.py により行う。
"""

from __future__ import annotations

from datetime import date

import pytest

from flightdeal.fetchers import FetchError, build_fetcher
from flightdeal.fetchers.stub import FixtureFetcher, StubFetcher


def test_build_fetcher_stub():
    assert isinstance(build_fetcher("stub"), StubFetcher)


def test_build_fetcher_unknown():
    with pytest.raises(ValueError):
        build_fetcher("nope")


def test_build_fetcher_playwright_not_implemented():
    with pytest.raises(NotImplementedError):
        build_fetcher("playwright")


def test_stub_returns_flights():
    flights = StubFetcher().fetch("HND", "HIJ", date(2026, 8, 1))
    assert len(flights) == 3
    assert all(f.price > 0 for f in flights)
    assert all(f.origin == "HND" and f.destination == "HIJ" for f in flights)


def test_stub_route_isolation():
    """意図的失敗を注入できること（要件4.3 の動作確認用）。"""
    fetcher = StubFetcher(fail_routes={"HND-HIJ"})
    with pytest.raises(FetchError):
        fetcher.fetch("HND", "HIJ", date(2026, 8, 1))
    # 別路線は影響を受けない
    assert fetcher.fetch("HND", "MYJ", date(2026, 8, 1))


def test_fixture_fetcher_missing_file(tmp_path):
    with pytest.raises(FetchError):
        FixtureFetcher(fixture_dir=tmp_path).fetch("HND", "HIJ", date(2026, 8, 1))


def test_fixture_fetcher_reads_saved_response():
    """Phase 0 で保存した実レスポンスのパース回帰テスト（要件6.2）。"""
    flights = FixtureFetcher().fetch("HND", "HIJ", date(2026, 8, 1))
    assert flights
    assert flights[0].airline
