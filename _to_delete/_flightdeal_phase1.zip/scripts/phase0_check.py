#!/usr/bin/env python3
"""Phase 0 技術検証スクリプト（要件2）。

手元PCで実行し、データ取得方式が使えるかを確認する。
完了条件: いずれかの方式で「3日連続」、価格・時刻・航空会社名が取得できること。

使い方:
    python scripts/phase0_check.py                 # HND -> HIJ の次の土曜を検証
    python scripts/phase0_check.py --dest MYJ
    python scripts/phase0_check.py --save          # 結果を tests/fixtures/raw/ へ保存

このスクリプトは GitHub Actions では実行しない（Bot判定検証は手元PCで行う）。
"""

from __future__ import annotations

import argparse
import json
import sys
from datetime import date, timedelta
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

RAW_DIR = ROOT / "tests" / "fixtures" / "raw"
LOG_PATH = ROOT / "docs" / "phase0_log.md"


def next_saturday(today: date) -> date:
    days = (5 - today.weekday()) % 7
    return today + timedelta(days=days or 7)


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("--origin", default="HND")
    p.add_argument("--dest", default="HIJ")
    p.add_argument("--date", default=None, help="YYYY-MM-DD（既定: 次の土曜）")
    p.add_argument("--save", action="store_true", help="生レスポンスを保存")
    args = p.parse_args()

    target = date.fromisoformat(args.date) if args.date else next_saturday(date.today())
    print(f"検証: {args.origin} -> {args.dest} / {target}")

    # --- 方式1: fast-flights ---
    print("\n[1] fast-flights")
    try:
        from fast_flights import FlightData, Passengers, get_flights  # type: ignore

        result = get_flights(
            flight_data=[FlightData(date=target.isoformat(), from_airport=args.origin, to_airport=args.dest)],
            trip="one-way",
            seat="economy",
            passengers=Passengers(adults=1),
            fetch_mode="fallback",
        )
        flights = getattr(result, "flights", [])
        print(f"    取得件数: {len(flights)}")
        for f in flights[:5]:
            print(f"    - {getattr(f, 'name', '?')} {getattr(f, 'departure', '?')} "
                  f"→ {getattr(f, 'arrival', '?')} {getattr(f, 'price', '?')} "
                  f"stops={getattr(f, 'stops', '?')}")

        if args.save and flights:
            RAW_DIR.mkdir(parents=True, exist_ok=True)
            out = RAW_DIR / f"{args.origin}-{args.dest}-{target}.fast-flights.json"
            out.write_text(
                json.dumps([vars(f) for f in flights], ensure_ascii=False, indent=2, default=str),
                encoding="utf-8",
            )
            print(f"    保存: {out}")

        print("\n チェックリスト:")
        print("   [ ] 航空会社名が取れているか")
        print("   [ ] 出発/到着時刻が取れているか")
        print("   [ ] 価格がJPYで取れているか")
        print("   [ ] 直行便（stops=0）に絞れるか")
        print(f"   [ ] {LOG_PATH.name} に本日の結果を記録したか（3日連続で成功が完了条件）")
        return 0

    except ImportError:
        print("    fast-flights が未インストールです: pip install -r requirements.txt")
        return 1
    except Exception as e:
        print(f"    失敗: {type(e).__name__}: {e}")
        print("    -> 連続で失敗する場合は方式2（Playwright）の実装を検討してください（要件3.2.2）")
        return 1


if __name__ == "__main__":
    sys.exit(main())
