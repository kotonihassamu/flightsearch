"""エントリポイント。

使い方:
    python -m flightdeal.main --status      実装状況（TODO一覧）を表示
    python -m flightdeal.main --dry-run     StubFetcher + コンソール通知で実行
    python -m flightdeal.main               config.json の設定どおりに実行

環境変数（要件4.4）:
    LINE_CHANNEL_ACCESS_TOKEN, LINE_TO_USER_ID
"""

from __future__ import annotations

import argparse
import logging
import sys
from dataclasses import replace
from datetime import date

from .config import load_config
from .fetchers import build_fetcher
from .logging_setup import setup_logging
from .notifiers import build_notifier

log = logging.getLogger(__name__)


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="flightdeal", description="週末格安航空券 自動発見・通知")
    p.add_argument("--config", default=None, help="config.json のパス")
    p.add_argument("--dry-run", action="store_true", help="StubFetcher + コンソール通知で実行")
    p.add_argument("--today", default=None, help="基準日を上書き (YYYY-MM-DD)。週末算出のテスト用")
    p.add_argument("--status", action="store_true", help="実装状況（TODO一覧）を表示して終了")
    p.add_argument("--verbose", action="store_true")
    return p


def print_status(config_path: str | None) -> int:
    """骨組みの実装状況を一覧表示する（開発の進捗確認用）。"""
    from . import status

    print(status.render(config_path))
    return 0


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    setup_logging(logging.DEBUG if args.verbose else logging.INFO)

    if args.status:
        return print_status(args.config)

    cfg = load_config(args.config)
    fetcher_name = "stub" if args.dry_run else cfg.fetcher
    notifier_name = "console" if args.dry_run else cfg.notifier

    if args.dry_run:
        # 外部サイトへ接続しないため、負荷抑制の待機は不要（要件4.3の対象外）
        cfg = replace(
            cfg, search=replace(cfg.search, sleep_between_searches=(0, 0), retry_wait_seconds=0)
        )

    today = date.fromisoformat(args.today) if args.today else date.today()

    log.info(
        "run_start",
        extra={
            "fetcher": fetcher_name,
            "notifier": notifier_name,
            "routes": [d.iata for d in cfg.enabled_destinations],
            "weekends_ahead": cfg.weekends_ahead,
            "today": today.isoformat(),
        },
    )

    # --- Phase 1 で有効化する本体 ---
    from . import formatter, pipeline

    with build_fetcher(fetcher_name) as fetcher:
        result = pipeline.run(fetcher, cfg, today=today)

    notifier = build_notifier(notifier_name)

    if result.all_failed:
        # 要件4.3: サイレント障害防止
        notifier.send(formatter.format_failure(result))
        log.error("run_all_failed", extra={"routes": len(result.results)})
        return 2

    body = formatter.format_run(result)
    if not body:
        log.info("run_no_deal", extra={"elapsed": result.elapsed_seconds})
        return 0

    notifier.send(body)
    log.info(
        "run_done",
        extra={"notified": len(result.notifiable), "elapsed": result.elapsed_seconds},
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
