"""優先度1: fast-flights を用いた取得実装（要件3.2.2）。

ブラウザ不要・軽量。ただし非公式ライブラリでありメンテ状況に依存するため、
Phase 0（`scripts/phase0_check.py`）で以下を必ず確認してから本採用すること。

  [ ] ライブラリの最新リリース日・Issue の状況
  [ ] HND -> HIJ の片道価格が取得できるか
  [ ] 取得結果に「航空会社名 / 出発時刻 / 到着時刻 / 価格」が揃っているか
  [ ] 価格が **JPY** で返っているか（通貨が異なる場合は換算が必要）
  [ ] 直行便に絞れているか（stops フィールドの型・値）
  [ ] 3日連続で成功するか（Phase 0 完了条件）

ライブラリの版によってフィールド名・時刻表記が変わりうるため、属性の取り出しは
複数の候補名を試す寛容な実装にしてある。Phase 0 で実レスポンスを確認したら、
`tests/fixtures/raw/` に保存して回帰テストを追加すること（要件6.2）。
"""

from __future__ import annotations

import logging
import re
import unicodedata
from datetime import date, time

from ..filters import is_complete
from ..models import Flight
from ..pricing import parse_price
from .base import FetchError, FlightFetcher

log = logging.getLogger(__name__)

# "7:25 AM on Sat, Aug 1" / "07:25" / "19:05" など
_TIME_RE = re.compile(r"(\d{1,2}):(\d{2})\s*([AaPp])?\.?[Mm]?\.?")


def parse_time_string(raw: str) -> time:
    """時刻文字列を time に変換する。

    対応する表記:
        "7:25 AM on Sat, Aug 1"  -> 07:25
        "7:25 PM"                -> 19:25
        "19:05"                  -> 19:05

    Raises:
        ValueError: 時刻を取り出せない場合
    """
    normalized = unicodedata.normalize("NFKC", str(raw)).strip()
    match = _TIME_RE.search(normalized)
    if not match:
        raise ValueError(f"時刻を解釈できません: {raw!r}")

    hour = int(match.group(1))
    minute = int(match.group(2))
    meridiem = (match.group(3) or "").lower()

    if meridiem == "p" and hour != 12:
        hour += 12
    elif meridiem == "a" and hour == 12:
        hour = 0

    if not (0 <= hour <= 23 and 0 <= minute <= 59):
        raise ValueError(f"時刻の値が範囲外です: {raw!r}")
    return time(hour, minute)


def _first_attr(obj: object, names: tuple[str, ...]) -> object | None:
    """候補名を順に試して最初に見つかった属性値を返す（版差の吸収）。"""
    for name in names:
        if isinstance(obj, dict):
            if name in obj and obj[name] is not None:
                return obj[name]
            continue
        value = getattr(obj, name, None)
        if value is not None:
            return value
    return None


def _is_nonstop(raw_stops: object) -> bool:
    """stops フィールドから直行便かどうかを判定する。

    None（取得できない）の場合は True 扱いにせず False を返し、除外する。
    直行便のみという要件3.1を満たせない便を通してしまう方が害が大きいため。
    """
    if raw_stops is None:
        return False
    if isinstance(raw_stops, bool):
        return not raw_stops
    if isinstance(raw_stops, int):
        return raw_stops == 0
    text = str(raw_stops).strip().lower()
    if text in ("0", "nonstop", "non-stop", "direct", "直行"):
        return True
    return bool(re.fullmatch(r"0\s*(stops?)?", text))


class FastFlightsFetcher(FlightFetcher):
    """fast-flights ラッパー。片道1検索を1回のAPI呼び出しで行う。"""

    name = "fast_flights"

    def __init__(self, seat: str = "economy", fetch_mode: str = "fallback") -> None:
        self.seat = seat
        self.fetch_mode = fetch_mode
        self.last_excluded = 0  # 直近の検索で除外した便数（要件3.2.2 ログ用）

    def fetch(self, origin: str, destination: str, flight_date: date) -> list[Flight]:
        try:
            from fast_flights import FlightData, Passengers, get_flights  # type: ignore
        except ImportError as e:
            raise FetchError(
                "fast-flights がインストールされていません。"
                "`pip install -r requirements.txt` を実行してください。"
            ) from e

        try:
            result = get_flights(
                flight_data=[
                    FlightData(
                        date=flight_date.isoformat(),
                        from_airport=origin,
                        to_airport=destination,
                    )
                ],
                trip="one-way",
                seat=self.seat,
                passengers=Passengers(adults=1),
                fetch_mode=self.fetch_mode,
            )
        except Exception as e:
            raise FetchError(
                f"fast-flights の取得に失敗しました ({origin}-{destination} {flight_date}): "
                f"{type(e).__name__}: {e}"
            ) from e

        raw_flights = _first_attr(result, ("flights",)) or []

        flights: list[Flight] = []
        excluded = 0
        for raw in raw_flights:
            converted = self._to_flight(raw, origin, destination, flight_date)
            if converted is None:
                excluded += 1
            else:
                flights.append(converted)

        self.last_excluded = excluded
        if excluded:
            log.info(
                "flights_excluded",
                extra={
                    "segment": f"{origin}-{destination}",
                    "date": flight_date.isoformat(),
                    "excluded": excluded,
                    "kept": len(flights),
                },
            )

        if not flights and raw_flights:
            # 全件除外は「取得できたがパースできない」= パーサ故障のサイン
            raise FetchError(
                f"{origin}-{destination} {flight_date}: "
                f"{len(raw_flights)}件取得しましたが全件を解釈できませんでした"
                "（ライブラリの仕様変更の可能性。tests/fixtures/raw/ に保存して調査）"
            )

        return flights

    def _to_flight(
        self, raw: object, origin: str, destination: str, flight_date: date
    ) -> Flight | None:
        """ライブラリの1件を Flight に変換する。欠損・非直行便なら None。"""
        airline = _first_attr(raw, ("name", "airline", "carrier"))
        departure = _first_attr(raw, ("departure", "depart", "departure_time"))
        arrival = _first_attr(raw, ("arrival", "arrive", "arrival_time"))
        price = _first_attr(raw, ("price", "fare"))
        stops = _first_attr(raw, ("stops", "stop_count", "num_stops"))
        number = _first_attr(raw, ("flight_number", "number", "flight_no"))

        if not _is_nonstop(stops):
            return None

        # 必須項目の欠損チェックは filters に集約する（要件3.2.2）
        if not is_complete(
            {
                "airline": airline,
                "depart_time": departure,
                "arrive_time": arrival,
                "price": price,
            }
        ):
            return None

        try:
            return Flight(
                origin=origin,
                destination=destination,
                flight_date=flight_date,
                airline=str(airline).strip(),
                depart_time=parse_time_string(str(departure)),
                arrive_time=parse_time_string(str(arrival)),
                price=parse_price(price if isinstance(price, (int, float)) else str(price)),
                flight_number=str(number).strip() if number else None,
            )
        except ValueError as e:
            log.debug("flight_parse_failed", extra={"error": str(e)})
            return None
