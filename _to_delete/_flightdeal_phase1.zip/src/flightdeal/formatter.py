"""通知本文の組み立て（要件3.6）。

原則: リンクが機能しなくても、本文情報だけで航空会社サイトから予約行動に移れること。

フォーマット例（要件3.6）:
    【S】羽田⇔広島 8/1(土)〜8/2(日)
    実質 ¥22,800（相場 ¥35,000 / ▲35%）
    往路: ANA 07:25発 → 08:50着（¥11,400）
    復路: ANA 19:05発 → 20:30着（¥11,400）
    補正: なし（FSC）
    検索: https://www.google.com/travel/flights?hl=ja&curr=JPY&q=HND to HIJ 2026-08-01
"""

from __future__ import annotations

from datetime import date, time
from urllib.parse import urlencode

from .models import Combination, Rank, RunResult

MAX_TEXT_LENGTH = 5000
WEEKDAY_JA = ["月", "火", "水", "木", "金", "土", "日"]

BLOCK_SEPARATOR = "\n\n"
FOOTER = "※表示価格は目安です。予約前に必ず各社サイトで空席・価格を確認してください。"


def yen(amount: int) -> str:
    """9800 -> '¥9,800'。"""
    return f"¥{amount:,}"


def hhmm(value: time) -> str:
    return f"{value.hour:02d}:{value.minute:02d}"


def search_url(origin: str, destination: str, flight_date: date) -> str:
    """Google Flights の検索URLを生成する（要件P5: 予約直リンクは使わない）。

    URL仕様の変更に弱い「検索結果URL」「予約直リンク」は使わず、日付と空港を
    埋めた検索クエリのみを渡す。リンクが切れても本文だけで行動できる前提。
    """
    query = urlencode(
        {
            "hl": "ja",
            "curr": "JPY",
            "q": f"{origin} to {destination} {flight_date.isoformat()}",
        }
    )
    return f"https://www.google.com/travel/flights?{query}"


def format_date_range(saturday: date, sunday: date) -> str:
    """'8/1(土)〜8/2(日)' 形式の文字列を返す。"""
    sat = f"{saturday.month}/{saturday.day}({WEEKDAY_JA[saturday.weekday()]})"
    sun = f"{sunday.month}/{sunday.day}({WEEKDAY_JA[sunday.weekday()]})"
    return f"{sat}〜{sun}"


def _surcharge_note(combo: Combination) -> str:
    """補正の内訳を1行で表す。"""
    total = combo.outbound_surcharge + combo.inbound_surcharge
    if total == 0:
        base = "なし（FSC）"
    else:
        parts = []
        if combo.outbound_surcharge:
            parts.append(f"往路+{yen(combo.outbound_surcharge)}")
        if combo.inbound_surcharge:
            parts.append(f"復路+{yen(combo.inbound_surcharge)}")
        base = f"手荷物 {' / '.join(parts)}"

    if combo.provisional_surcharge:
        base += "（※補正額は仮。航空会社が未分類のため実際と異なる場合あり）"
    return base


def format_combination(combo: Combination) -> str:
    """1件分の通知ブロックを組み立てる（要件3.6 の必須項目をすべて含む）。"""
    route = combo.route
    weekend = combo.weekend
    out, ret = combo.outbound, combo.inbound
    discount = round(combo.discount_rate * 100)

    lines = [
        f"【{combo.rank.value}】羽田⇔{route.name} {format_date_range(weekend.saturday, weekend.sunday)}",
        f"実質 {yen(combo.total_price)}（相場 {yen(route.market_price)} / ▲{discount}%）",
        f"往路: {out.airline} {hhmm(out.depart_time)}発 → {hhmm(out.arrive_time)}着"
        f"（{yen(out.price)}{_flight_no(out.flight_number)}）",
        f"復路: {ret.airline} {hhmm(ret.depart_time)}発 → {hhmm(ret.arrive_time)}着"
        f"（{yen(ret.price)}{_flight_no(ret.flight_number)}）",
        f"補正: {_surcharge_note(combo)}",
        f"検索: {search_url(out.origin, out.destination, weekend.saturday)}",
    ]
    return "\n".join(lines)


def _flight_no(number: str | None) -> str:
    return f" / {number}" if number else ""


_RANK_ORDER = {Rank.S: 0, Rank.A: 1, Rank.B: 2, Rank.NONE: 3}


def format_run(result: RunResult) -> str:
    """全結果を1通に集約した本文を返す（要件3.6 集約）。

    ランク入りが0件なら空文字を返す。呼び出し側は通知しない。
    """
    combos = result.notifiable
    if not combos:
        return ""

    combos = sorted(
        combos,
        key=lambda c: (c.route.iata, c.weekend.index, c.total_price, c.outbound.depart_time),
    )

    header = f"週末の格安便が {len(combos)}件 見つかりました"
    blocks = [header] + [format_combination(c) for c in combos] + [FOOTER]
    return BLOCK_SEPARATOR.join(blocks)


def format_failure(result: RunResult) -> str:
    """全路線失敗時の障害通知本文（要件4.3 サイレント障害防止）。

    スタックトレースは載せない。運用者が次に何をすべきかだけを伝える。
    """
    lines = ["⚠️ 航空券の取得に失敗しました（全路線）", ""]
    for r in result.results:
        reason = (r.error or "不明").splitlines()[0][:120]
        lines.append(f"・{r.route.name}({r.route.iata}) {r.weekend.saturday}: {reason}")

    lines += [
        "",
        "取得元の仕様変更、またはBot判定によるIPブロックの可能性があります。",
        "全路線の失敗が3日連続した場合は、ローカル実行（自宅PC / Raspberry Pi）へ",
        "切り替えてください（docs/運用手順.md 参照）。",
    ]
    return "\n".join(lines)


def split_message(text: str, limit: int = MAX_TEXT_LENGTH) -> list[str]:
    """LINEの文字数上限で分割する（要件3.6: 5,000文字超の場合のみ分割）。

    1件分のブロック（空行区切り）の途中では切らない。
    単独で limit を超えるブロックのみ、やむを得ず文字数で切る。
    """
    if len(text) <= limit:
        return [text]

    chunks: list[str] = []
    current = ""

    for block in text.split(BLOCK_SEPARATOR):
        candidate = block if not current else current + BLOCK_SEPARATOR + block

        if len(candidate) <= limit:
            current = candidate
            continue

        if current:
            chunks.append(current)
            current = ""

        if len(block) <= limit:
            current = block
        else:
            # 単独ブロックが上限超え（通常は起きない）。行単位 -> 文字数で切る。
            for piece in _hard_split(block, limit):
                chunks.append(piece)

    if current:
        chunks.append(current)
    return chunks


def _hard_split(block: str, limit: int) -> list[str]:
    pieces: list[str] = []
    current = ""
    for line in block.split("\n"):
        candidate = line if not current else current + "\n" + line
        if len(candidate) <= limit:
            current = candidate
            continue
        if current:
            pieces.append(current)
            current = ""
        while len(line) > limit:
            pieces.append(line[:limit])
            line = line[limit:]
        current = line
    if current:
        pieces.append(current)
    return pieces
