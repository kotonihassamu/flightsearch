"""取得層のテスト。

外部サイトへ接続するテストは書かない（要件6.2: CIの合否条件に含めない）。
実取得の検証は Phase 0 で手元PCの scripts/phase0_check.py により行う。
"""

from __future__ import annotations

from datetime import date, time

import pytest

from flightdeal.fetchers import FetchError, build_fetcher
from flightdeal.fetchers.fast_flights_fetcher import (
    FastFlightsFetcher,
    _is_nonstop,
    parse_time_string,
)
from flightdeal.fetchers.stub import FixtureFetcher, StubFetcher


def test_build_fetcher_stub():
    assert isinstance(build_fetcher("stub"), StubFetcher)


def test_build_fetcher_unknown():
    with pytest.raises(ValueError):
        build_fetcher("nope")


def test_build_fetcher_playwright_not_implemented():
    with pytest.raises(NotImplementedError):
        build_fetcher("playwright")


def test_stub_returns_flights():
    flights = StubFetcher().fetch("HND", "HIJ", date(2026, 8, 1))
    assert len(flights) == 3
    assert all(f.price > 0 for f in flights)
    assert all(f.origin == "HND" and f.destination == "HIJ" for f in flights)


def test_stub_route_isolation():
    """意図的失敗を注入できること（要件4.3 の動作確認用）。"""
    fetcher = StubFetcher(fail_routes={"HND-HIJ"})
    with pytest.raises(FetchError):
        fetcher.fetch("HND", "HIJ", date(2026, 8, 1))
    # 別路線は影響を受けない
    assert fetcher.fetch("HND", "MYJ", date(2026, 8, 1))


def test_fixture_fetcher_missing_file(tmp_path):
    with pytest.raises(FetchError):
        FixtureFetcher(fixture_dir=tmp_path).fetch("HND", "HIJ", date(2026, 8, 1))


def test_fixture_fetcher_reads_saved_response():
    """Phase 0 で保存した実レスポンスのパース回帰テスト（要件6.2）。"""
    flights = FixtureFetcher().fetch("HND", "HIJ", date(2026, 8, 1))
    assert flights
    assert flights[0].airline


# --- fast-flights のパース部（外部接続なし） ---


@pytest.mark.parametrize(
    "raw,expected",
    [
        ("7:25 AM on Sat, Aug 1", time(7, 25)),
        ("7:25 PM", time(19, 25)),
        ("12:05 AM", time(0, 5)),
        ("12:05 PM", time(12, 5)),
        ("19:05", time(19, 5)),
        ("08:50 on Sun, Aug 2", time(8, 50)),
    ],
)
def test_parse_time_string(raw, expected):
    assert parse_time_string(raw) == expected


def test_parse_time_string_invalid():
    with pytest.raises(ValueError):
        parse_time_string("時刻不明")


@pytest.mark.parametrize(
    "stops,expected",
    [(0, True), ("0", True), ("Nonstop", True), (1, False), ("1 stop", False), (None, False)],
)
def test_is_nonstop(stops, expected):
    assert _is_nonstop(stops) is expected


class _Raw:
    """fast-flights が返すオブジェクトを模した最小のスタブ。"""

    def __init__(self, **kw):
        for k, v in kw.items():
            setattr(self, k, v)


def test_to_flight_maps_fields():
    raw = _Raw(name="ANA", departure="7:25 AM on Sat, Aug 1",
               arrival="8:50 AM on Sat, Aug 1", price="¥11,400", stops=0)
    flight = FastFlightsFetcher()._to_flight(raw, "HND", "HIJ", date(2026, 8, 1))

    assert flight is not None
    assert flight.airline == "ANA"
    assert flight.depart_time == time(7, 25)
    assert flight.arrive_time == time(8, 50)
    assert flight.price == 11400


def test_to_flight_excludes_connecting_flight():
    raw = _Raw(name="ANA", departure="7:25 AM", arrival="11:50 AM", price="¥9,000", stops=1)
    assert FastFlightsFetcher()._to_flight(raw, "HND", "HIJ", date(2026, 8, 1)) is None


def test_to_flight_excludes_incomplete_record():
    """取得項目が欠けた便は除外する（要件3.2.2）。"""
    raw = _Raw(name="ANA", departure="7:25 AM", arrival=None, price="¥9,000", stops=0)
    assert FastFlightsFetcher()._to_flight(raw, "HND", "HIJ", date(2026, 8, 1)) is None
